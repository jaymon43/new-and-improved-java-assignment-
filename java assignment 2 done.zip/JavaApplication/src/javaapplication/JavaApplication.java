/**
	File name: JavaApplication.java
	Short description:
	IST 242 Assignment:
	@author Jared Furline
	@version 1.01 ?/??/????
*/ 
package javaapplication;

/**
 *
 * @author jfurl
 */
public class JavaApplication {

    private static Object Jared;
public static void main(String[] args) {
     //Create two MyDate objects
     MyDate date1 = new MyDate();
     MyDate date2 = new MyDate(34355555133101L);

     System.out.println("Date1: " + date1.getMonth() + "/" + date1.getDay() + 
         "/" + date1.getYear());
     System.out.println("Date2: " + date2.getMonth() + "/" + date2.getDay() + 
        "/" + date2.getYear());


        Person person = new Person("Chris ");
        Student student = new Student("Peter");
        Employee employee = new Employee("Dr.Max");
        Faculty faculty = new Faculty("4");
        Staff staff = new Staff("Dr.Leon");

        System.out.println(person.toString());
        System.out.println(student.toString());
        System.out.println(employee.toString());
        System.out.println(faculty.toString());
        System.out.println(staff.toString());

   
}
}

    /**
            File name: Person.java
            Short description:
            IST 242 Assignment:
            @author Jared Furline
            @version 1.01 ?/??/????
    */
    package javaapplication;

    /**
     *
     * @author jfurl
     */
    public class Person {

        public String name;
        public String address;
        public String phoneNumber;
        public String email;

        public Person(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        @Override
        public String toString() {
            return "Name: " + getName() + " Class: " + this.getClass().getName();
        }
    }
/**
	File name: MyDate.java
	Short description:
	IST 242 Assignment:
	@author Jared Furline
	@version 1.01 ?/??/????
*/
package javaapplication;

import java.util.Calendar;
/**
 *
 * @author jfurl
 */

  class MyDate{
	  Calendar c = Calendar.getInstance();
	  private int year, month, day;
	  
	  public MyDate(){
		  this(System.currentTimeMillis());
	  }
	  
	  public MyDate(long millis){
		  setDate(millis);
	  }
	  
	  public MyDate(int year, int month, int day){
		  this.year = year;
		  this.month = month;
		  this.day = day;
	  }
	  
	  public int getYear(){
		  return year;
	  }
	  
	  public int getMonth(){
		  return month;
	  }
	  
	  public int getDay(){
		  return day;
	  }
	  
	  public void setDate(long millis){
		  c.setTimeInMillis(millis);
		  year = c.get(Calendar.YEAR);
		  month = c.get(Calendar.MONTH);
		  day = c.get(Calendar.DAY_OF_MONTH);
	  }
	  
	  public void display(){
		System.out.printf("%d/%d/%d (mm/dd/yyyy)\n", month, day, year);
	}
  }
  